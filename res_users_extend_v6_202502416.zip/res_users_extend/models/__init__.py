# -*- coding: utf-8 -*-

from . import res_users
from . import res_company_ldap
from . import hr_employee
from . import res_partner